import Vue from 'vue' // 引入vue
import App from './App.vue' // 引入App.vue文件模块， 这个文件是作为所有vue组件的入口

Vue.config.productionTip = false // 一个控制台打印的提示

new Vue({ // 实例化vue对象
  render: h => h(App), // 告诉vue去渲染 App.vue 页面
}).$mount('#app') // $mount是让这个渲染页面放置在public/index.html中带有id为app的div中
