<template>
  <div id="app">
    hello world
  </div>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style scoped>
</style>
